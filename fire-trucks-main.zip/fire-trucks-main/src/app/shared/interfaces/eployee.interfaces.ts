export interface Employees {
    name: string;
    surname: string;
  }