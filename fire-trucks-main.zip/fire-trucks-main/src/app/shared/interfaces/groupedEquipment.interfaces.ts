import { Equipment } from "./equipments.interfaces";

export interface GroupedEquipment {
    position: string;
    items: Equipment[];
  }