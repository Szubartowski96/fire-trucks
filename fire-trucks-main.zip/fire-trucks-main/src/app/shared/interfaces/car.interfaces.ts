export interface Car {
    value: string;
    viewValue: string;
  }