export interface Equipment {
    position: string;
    name: string;
    count: number;
    comments: string;
  }
  